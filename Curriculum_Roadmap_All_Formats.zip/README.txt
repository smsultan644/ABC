CURRICULUM ROADMAP DOWNLOAD PACKAGE
====================================
Exness Trading Mastery Program - 6-Month Foundational Curriculum
Document Version 1.0 - Created 2026-08-19

CONTENTS:
1. PERSONALIZED_CURRICULUM_ROADMAP.pdf   - 28-page PDF (recommended)
2. PERSONALIZED_CURRICULUM_ROADMAP.docx  - Editable Word document
3. PERSONALIZED_CURRICULUM_ROADMAP.md    - Markdown source

START HERE: Open the PDF first and review the Executive Summary (Part II).
Next: Confirm readiness and begin Module 1.1 - Financial Market Reality.

IMPORTANT:
- This is a 6-month curriculum blueprint, not a profit promise.
- Live trading is gated by competency assessment (>= 80/100).
- Consult a Bangladeshi legal professional before live trading.
